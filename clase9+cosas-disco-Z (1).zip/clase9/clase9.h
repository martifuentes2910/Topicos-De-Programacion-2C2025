#ifndef CLASE9_H_INCLUDED
#define CLASE9_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

int cmpEntAsc(const void*, const void*);
//void* buscarMenor(const void*, size_t, size_t, int(const void*, const void*));
//void adSeleccion(void*,size_t,size_t, int(const void*, const void*));
void* _bsearch(const void*, const void*, size_t, size_t, int (const void*,const void*));
//void qsort(void*, size_t, size_t, int (const void*,const void*))

#endif // CLASE9_H_INCLUDED
