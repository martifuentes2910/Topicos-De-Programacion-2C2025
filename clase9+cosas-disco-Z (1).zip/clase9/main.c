#include "clase9.h"

int main()
{
    //int vector[]= {2,4,1,800,10};
    int vector2[] = {1,2,4,8,16,32,64};
    int clave=4;
    int* elem;
    /*qsort(vector, sizeof(vector)/sizeof(int),sizeof(int), cmpEntAsc);
    for(int i=0; i<sizeof(vector)/sizeof(int); i++)
    {
        printf("\n%d", vector[i]);
    }*/

   // buscarMenor(vector, sizeof(vector)/sizeof(int),sizeof(int), cmpEntAsc);
   // qsort(vector, sizeof(vector)/sizeof(int),sizeof(int), cmpEntAsc);
    if(elem=_bsearch(clave, vector2,  sizeof(vector2)/sizeof(int),sizeof(int), cmpEntAsc)!=NULL)
        printf( "Encontrado: %d\n", *elem );
    else
        printf( "No encontrado: %d\n", clave );
    return 0;
}
