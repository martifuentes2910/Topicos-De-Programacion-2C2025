#include "clase9.h"

int cmpEntAsc(const void*a, const void*b)
{
    return *((int*)a)-*((int*)b);
}

void* buscarMenor(const void*vec, size_t ce, size_t tam, int cmpEntAsc(const void*a, const void*b))
{
    void*menor=(void*)vec;
    while(ce/tam)
    {
        if(cmpEntAsc(menor, vec)<0)
        {
            menor=(void*)vec;
        }
        vec+=tam;
    }

    return menor;
}

void ordenaSeleccion(void*vec,size_t ce,size_t tam, int cmp(const void*a, const void*b))//trae el menor y lo fija al inicio
{
    void*finfin=vec+(tam*(ce-1));
    void* menor = buscarMenor(vec, ce, tam, cmpEntAsc);
                  while(vec<finfin)
    {

    }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void* _bsearch(const void*clave, const void* base, size_t ce, size_t tam, int cmp(const void*,const void*))
{
    //clave es la cosa que quiero buscar
    void*pm=(int*)base+(ce/2)*tam;
    int c= cmp(pm, clave);
    void *ini=(int*)base;
    int fin=ce-*((int*)pm)-1;
    if(c==0)
        return pm;
    if(c>0)
    {
        for(ini; ini<*((int*)pm); ini+=tam)
            if(cmp(pm,clave)==0)
                return pm;
    }
    else if(c<0)
    {

        for(pm; pm<fin; pm+=tam)
        {
            if(cmp(pm,clave)==0)
                return pm;
        }

    }
    else
        return NULL;
}
